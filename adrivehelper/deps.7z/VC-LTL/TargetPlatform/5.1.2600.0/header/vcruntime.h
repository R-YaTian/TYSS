﻿
#include "..\..\header\VC_LTL_Config.h"

#ifndef _LTL_vcruntime_module_type
#define _LTL_vcruntime_module_type 1/*_LTL_vcruntime_module_type_from_msvcrt*/
#endif


#ifndef _LTL_ucrt_module_type
#define _LTL_ucrt_module_type 1/*_LTL_ucrt_module_type_from_msvcrt*/
#endif


#ifndef _LTL_vccorlib_module_type
#define _LTL_vccorlib_module_type 0/*_LTL_vccorlib_module_type_form_vccorlib140*/
#endif

#include <..\include\vcruntime.h>

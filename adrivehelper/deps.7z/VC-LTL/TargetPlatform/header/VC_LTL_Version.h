﻿
#ifndef __LTL_Version_Include
#define __LTL_Version_Include

#define LTLVersion1 5
#define LTLVersion2 0
#define LTLVersion3 1
#define LTLVersion4 4

#endif
